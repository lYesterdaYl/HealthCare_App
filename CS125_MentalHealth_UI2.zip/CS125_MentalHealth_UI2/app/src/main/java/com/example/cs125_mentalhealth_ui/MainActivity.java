package com.example.cs125_mentalhealth_ui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText etUsername;
    private EditText etPassword;
    private Button signIn;
    private Button signUp;
    private TextView invalidText;
    private String username;
    private String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        signIn = findViewById(R.id.btnSignIn);
        signUp = findViewById(R.id.btnSignUp);
        invalidText = findViewById(R.id.tvInvalid);

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(etUsername.getText().toString(), etPassword.getText().toString());
            }
        });

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                reg();
            }
        });

    }

    private void reg(){
        Intent reg = new Intent(MainActivity.this, SignUpActivity.class);
        startActivity(reg);
    }

    private void validate(String name, String userPassword){
        //get name and password checked in db
        if(name.equals("admin") && userPassword.equals("1234")){
            Intent dashboard = new Intent(MainActivity.this, DashboardActivity.class);
            invalidText.setVisibility(View.INVISIBLE);
            username = name;
            password = userPassword;
            startActivity(dashboard);
        }
        else
        {
            invalidText.setVisibility(View.VISIBLE);
        }
    }

}
