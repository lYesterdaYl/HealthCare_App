package com.example.cs125_mentalhealth_ui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class DashboardActivity extends AppCompatActivity {
    private char[] answers = null;
    private String username;
    private String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        Intent i = getIntent();
        username = i.getStringExtra("username");
        password = i.getStringExtra("password");

        if(answers == null){
            Intent survey = new Intent(DashboardActivity.this, Survey.class);
            startActivity(survey);
            answers = survey.getCharArrayExtra("answers");
        }
    }
}
