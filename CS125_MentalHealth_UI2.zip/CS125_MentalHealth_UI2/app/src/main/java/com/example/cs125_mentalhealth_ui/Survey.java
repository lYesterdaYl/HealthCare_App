package com.example.cs125_mentalhealth_ui;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Survey extends AppCompatActivity {
    private String[] questions = {"I don’t know why I always feel flustered and restless.",
    "After going to bed, I can't sleep, even if I fall asleep, it is easy to wake up.",
            "Learning often makes you feel very annoyed and hates learning.",
            "Even if it is a small matter, it is always too open to thinking about it all day long.",
            "I often quarrel with people and get angry, and then regret it.",
    "I look down on myself and feel that others are always laughing at myself.",
    "When participating in group activities, there is always a sense of loneliness.",
    "Question 8",
    "Question 9",
    "Question 10"};
    private char[] answers = new char[10];
    private Button selectA;
    private Button selectB;
    private Button selectC;
    private TextView question;
    private int counter = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survey);

        question = findViewById(R.id.tvQuestion);
        question.setText(questions[0]);
        selectA = findViewById(R.id.btnSelectA);
        selectB = findViewById(R.id.btnSelectB);
        selectC = findViewById(R.id.btnSelectC);

        selectA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                record('A');
            }
        });

        selectB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                record('B');
            }
        });

        selectC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                record('C');
            }
        });
    }

    private void record(char newAnswer){
        answers[counter] = newAnswer;
        counter++;
        if (counter >= 10)
        {
            this.finish();
        }else{
            question.setText(questions[counter]);
        }
        //update question

    }
}
